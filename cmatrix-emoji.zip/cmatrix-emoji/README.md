# 🟢 Emoji CMatrix

A modified version of [CMatrix](https://github.com/abishekvashok/cmatrix), using its actual C scrolling engine with emoji rain enabled by default. Compiles locally against wide-character ncurses; no Python, downloads at startup, or system-wide program installation.

## 🚀 Install and start

Extract this folder, open a terminal in it, then:

```bash
bash install-dep.sh
bash start.sh
```

The dependency installer supports Debian/Ubuntu/ChromeOS Linux, Fedora, and Arch. It uses sudo only for system packages. Build and start as your normal user. Dependencies: C compiler, pkg-config, ncursesw development headers, and an emoji font. Once dependencies are present, `bash build.sh` builds offline.

```bash
bash start.sh -r           # 🌈 Rainbow
bash start.sh -A -C cyan   # Classic ASCII in cyan
bash start.sh -e -u 2      # Fast emoji rain
bash start.sh -s           # Exit on any key
bash start.sh -h           # All upstream options
```

| Key | Action |
| --- | --- |
| e | Toggle emoji / ASCII |
| p | Pause / resume |
| 1–9 | Delay: 1 fastest, 9 slowest |
| r | Rainbow colors |
| ! @ # $ % ^ & | Red, green, yellow, blue, magenta, cyan, white |
| q or Ctrl+C | Quit and restore terminal |

Use a UTF-8 graphical terminal with an emoji font. Terminal/font support determines whether emoji appear in color. Single-codepoint emoji occupy up to two cells; unsupported glyphs may appear as boxes. `-A` provides an ASCII fallback. `-c` and font-specific upstream modes are best used with `-A`. Upstream `-L` is an animation mode, **not a secure screen lock**.

## Source and license

GPL-3.0-or-later; see COPYING. Original CMatrix copyright: Chris Allegretta (1999–2017), Abishek V Ashok (2017–Present). Upstream source: https://github.com/abishekvashok/cmatrix . Original unmodified source is included as `cmatrix.upstream.c`; its Git blob SHA is `7d8ca3935ef89598ff285b0dd416d4c13e9a042e`.

Modifications dated 2026-11-05: emoji rendering through ncursesw, `-e` / `-A` and interactive `e`, bounded delay, small-terminal allocation fixes, SIGTERM cleanup, local build and launch scripts. Emoji mapping is stable for each cell value. The original stream generation and keyboard controls are retained.

To publish, create an empty GitHub repository, then run in this folder:

```bash
git init -b main
git add .
git commit -m "Add Emoji CMatrix derived from upstream CMatrix"
git remote add origin https://github.com/dibend/cmatrix-emoji.git
git push -u origin main
```
