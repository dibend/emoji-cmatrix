#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
command -v "${CC:-cc}" >/dev/null || { echo '❌ Compiler missing. Run bash install-dep.sh'; exit 1; }
command -v pkg-config >/dev/null && pkg-config --exists ncursesw || {
  echo '❌ Wide ncurses development files missing. Run bash install-dep.sh'; exit 1;
}
mkdir -p build
flags=(-D_DEFAULT_SOURCE -D_XOPEN_SOURCE=600 -DEXCLUDE_CONFIG_H
  -DHAVE_GETOPT_H -DHAVE_NCURSES_H -DHAVE_SYS_IOCTL_H -DHAVE_UNISTD_H
  -DHAVE_TERMIOS_H -DHAVE_RESIZETERM -DHAVE_WRESIZE -DHAVE_USE_DEFAULT_COLORS
  '-DVERSION="emoji-1.0"')
read -r -a cflags <<< "$(pkg-config --cflags ncursesw)"
read -r -a libs <<< "$(pkg-config --libs ncursesw)"
printf '🔨 Building Emoji CMatrix…\n'
"${CC:-cc}" -std=c11 -O2 -Wall -Wextra "${flags[@]}" "${cflags[@]}" cmatrix.c -o build/cmatrix-emoji.tmp "${libs[@]}"
mv build/cmatrix-emoji.tmp build/cmatrix-emoji
printf '✅ Build complete!\n'
