#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
as_root() {
  if (( EUID == 0 )); then "$@";
  elif command -v sudo >/dev/null; then sudo "$@";
  else printf '❌ Run the package installation as root or install sudo.\n' >&2; exit 1; fi
}
printf '📦 Installing compiler, wide ncurses, and emoji fonts…\n'
if command -v apt-get >/dev/null; then
  as_root apt-get update
  as_root apt-get install -y build-essential pkg-config libncurses-dev fonts-noto-color-emoji
elif command -v dnf >/dev/null; then
  as_root dnf install -y gcc pkgconf-pkg-config ncurses-devel google-noto-color-emoji-fonts
elif command -v pacman >/dev/null; then
  as_root pacman -S --needed base-devel pkgconf ncurses noto-fonts-emoji
else
  printf '❌ Supported: Debian/Ubuntu/ChromeOS Linux, Fedora, Arch.\n' >&2
  printf 'Install a C compiler, pkg-config, wide ncurses headers and an emoji font, then run bash build.sh.\n' >&2
  exit 1
fi
bash ./build.sh
printf '🎉 Ready! Run: bash start.sh\n'
