#!/usr/bin/env bash
# SPDX-License-Identifier: GPL-3.0-or-later
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
if [[ ! -x build/cmatrix-emoji || cmatrix.c -nt build/cmatrix-emoji || build.sh -nt build/cmatrix-emoji ]]; then
  bash ./build.sh
fi
case "${1:-}" in -h|-V) exec ./build/cmatrix-emoji "$@" ;; esac
[[ -t 0 && -t 1 ]] || { echo '❌ Open a terminal to run the animation.' >&2; exit 1; }
[[ -n ${TERM:-} && ${TERM} != dumb ]] || { echo '❌ A terminal with curses support is required.' >&2; exit 1; }
if ! locale charmap 2>/dev/null | grep -qi 'utf-*8'; then
  utf_locale=$(locale -a | grep -Ei '^(C|en_US)\.utf-?8$' | head -n 1 || true)
  [[ -n "$utf_locale" ]] || { echo '❌ Enable a UTF-8 locale first.' >&2; exit 1; }
  export LC_ALL="$utf_locale"
fi
printf '🟢 Emoji CMatrix | e: emoji/ASCII · p: pause · 1–9: speed · q: quit\n'
exec ./build/cmatrix-emoji -a -b "$@"
